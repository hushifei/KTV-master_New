//
//  LoginAndRegister.h
//  LoginAndRegister
//
//  Created by stevenhu on 15/11/22.
//  Copyright © 2015年 stevenhu. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for LoginAndRegister.
FOUNDATION_EXPORT double LoginAndRegisterVersionNumber;

//! Project version string for LoginAndRegister.
FOUNDATION_EXPORT const unsigned char LoginAndRegisterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoginAndRegister/PublicHeader.h>

@interface LoginAndRegister :NSObject

@end

