//
//  CYloginRegisterViewController.h
//  聪颖不聪颖
//
//  Created by 葛聪颖 on 15/9/27.
//  Copyright © 2015年 gecongying. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYloginRegisterViewController : UIViewController

@end
